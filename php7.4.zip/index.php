<?php

require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer\Xls;

// Sample data
$data = [
    ['id' => 1, 'name' => 'Item 1', 'last_update' => '2023-04-03'],
    ['id' => 2, 'name' => 'Item 2', 'last_update' => '2023-04-05'],
    ['id' => 3, 'name' => 'Item 3', 'last_update' => '2023-04-07'],
];

// Create a new Spreadsheet object
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Write headers
$headers = ['ID', 'Name', 'Last Update'];
$col = 0;
foreach ($headers as $header) {
    $sheet->setCellValueByColumnAndRow($col + 1, 1, $header);
    $col++;
}

// Write data to the sheet
$row = 2;
foreach ($data as $rowItem) {
    $col = 0;
    foreach ($rowItem as $key => $value) {
        if ($key === 'last_update') {
            $date = \PhpOffice\PhpSpreadsheet\Shared\Date::PHPToExcel(new \DateTime($value));
            $sheet->setCellValueByColumnAndRow($col + 1, $row, $date);
            $sheet->getStyleByColumnAndRow($col + 1, $row)->getNumberFormat()->setFormatCode('yyyy-mm-dd');
        } else {
            $sheet->setCellValueByColumnAndRow($col + 1, $row, $value);
        }
        $col++;
    }
    $row++;
}

// Set autofilter on the data range
$lastColumn = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($col);
$dataRange = "A1:$lastColumn$row";
$sheet->setAutoFilter($dataRange);

// Save the Excel file to a temporary location
$filename = 'data.xlsx';
$writer = new Xlsx($spreadsheet);
$tempFile = tempnam(sys_get_temp_dir(), 'excel');
$writer->save($tempFile);

// Send the file to the browser for download
header('Content-Description: File Transfer');
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($tempFile));
ob_clean();
flush();
readfile($tempFile);
unlink($tempFile); // Delete the temporary file
exit;

?>
